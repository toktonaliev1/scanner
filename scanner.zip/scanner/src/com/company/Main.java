package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner Ab = new Scanner(System.in);
        System.out.println("привет!");
        String BC = Ab.nextLine();
        System.out.println("привет ");
        Scanner db = new Scanner(System.in);
        System.out.println("как дела?");
        String hg = db.nextLine();
        System.out.println("хорошо нормально "  );



    }
}
